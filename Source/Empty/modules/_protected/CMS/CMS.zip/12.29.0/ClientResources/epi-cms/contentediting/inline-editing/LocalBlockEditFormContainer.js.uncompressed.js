define("epi-cms/contentediting/inline-editing/LocalBlockEditFormContainer", [
    "dojo/_base/declare",
    "dojo/Deferred",
    "dojo/on",
    "dojo/Evented",
    "epi",
    "epi/shell/tooltipHider",
    "epi-cms/contentediting/ContentActionSupport",

    "epi/shell/widget/FormContainer"
], function (
    declare,
    Deferred,
    on,
    Evented,
    epi,
    tooltipHider,
    ContentActionSupport,
    FormContainer) {

    return declare([FormContainer, Evented], {
        contentLink: null,
        isDirty: false,
        initialValue: null,

        _onIsDirty: function () {
            var isDirty = !epi.areEqual(this.get("initialValue"), this.get("value"));

            this.set("isDirty", isDirty);
            this.emit("isDirty", isDirty);
        },

        postCreate: function () {
            this.inherited(arguments);

            this.own(on(this, "FormCreated", function () {
                tooltipHider(this.form.getParent());
                this.onChange = this._onIsDirty.bind(this);

                this.own(on(this, "change", this._onIsDirty.bind(this)));
                this.own(on(this.domNode, "change", this._onIsDirty.bind(this)));
                this.own(on(this.domNode, "keyup", this._onIsDirty.bind(this)));
                this.initialValue = this.get("value");
            }.bind(this)));
        },

        layout: function () {
            this.inherited(arguments);
            if (this.containerLayout) {
                this.containerLayout.containerNode.style.removeProperty("height");
                this.containerLayout.containerNode.style.removeProperty("width");
            }
        },

        _onFormCreated: function () {
            this.inherited(arguments);

            if (this._model && !this._model.canChangeContent(ContentActionSupport.action.Edit)) {
                this.set("readOnly", true);
            }
        },

        _hideProperty: function (metadata, propertyName) {
            metadata.properties.some(function (property) {
                if (property.name === propertyName) {
                    property.showForEdit = false;
                    return true;
                }
                return false;
            });
        },

        _disableNonLanguageSpecificProperties: function (metadata) {
            metadata.properties.forEach(function (property) {
                if (!property.settings.isLanguageSpecific) {
                    property.showForEdit = false;
                }
            }.bind(this));
        },

        _setMetadataAttr: function (metadata) {
            var settings = (metadata.customEditorSettings || {}).inlineBlock;

            if (!settings) {
                console.warn("Metadata was not initialized properly");
                settings = {};
            }

            if (!settings.showNameProperty) {
                this._hideProperty(metadata, "icontent_name");
            }
            if (!settings.showCategoryProperty) {
                this._hideProperty(metadata, "icategorizable_category");
            }

            if (this.get("isTranslationNeeded")) {
                this._disableNonLanguageSpecificProperties(metadata);
            }

            metadata.properties.forEach(function (property) {
                property.settings.isInQuickEditMode = true;
                property.settings.quickEditBlockId = this.contentLink;
            }.bind(this));

            var hiddenGroups = settings.hiddenGroups.map(function (x) {
                return x.toLowerCase();
            });
            var numberOfVisibleGroups = metadata.groups.filter(function (x) {
                return x.name !== "EPiServerCMS_SettingsPanel" && hiddenGroups.indexOf(x.name.toLowerCase()) === -1;
            }).length;

            // Change group properties container to epi-cms/layout/CreateContentGroup
            metadata.layoutType = "epi/shell/layout/SimpleContainer";
            metadata.groups.forEach(function (group) {
                group.uiType = "epi-cms/layout/CreateContentGroupContainerNoHeader";

                if (group.name === "EPiServerCMS_SettingsPanel") {
                    group.options = {};
                    group.title = null;
                } else {
                    if (numberOfVisibleGroups > 1) {
                        group.uiType = "epi-cms/layout/CreateContentGroupContainer";
                    }
                }

                // by default Settings tab is not displayed
                if (hiddenGroups.indexOf(group.name.toLowerCase()) !== -1) {
                    group.displayUI = false;
                }
            });
            this._set("metadata", metadata);

            this.startup();
        }
    });
});
