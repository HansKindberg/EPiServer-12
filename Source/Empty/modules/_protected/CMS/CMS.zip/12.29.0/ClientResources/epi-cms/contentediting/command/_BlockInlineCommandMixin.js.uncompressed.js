define("epi-cms/contentediting/command/_BlockInlineCommandMixin", [
    "dojo/_base/declare",
    "dojo/topic",
    "dojo/when",
    "dojox/html/entities",
    "epi/dependency",
    "epi-cms/contentediting/ContentActionSupport",
    "epi-cms/core/ContentReference",
    "epi-cms/contentediting/ContentViewModel",
    "epi/shell/DialogService",
    "epi/shell/TypeDescriptorManager"
], function (
    declare,
    topic,
    when,
    htmlEntities,
    dependency,
    ContentActionSupport,
    ContentReference,
    ContentViewModel,
    DialogService,
    TypeDescriptorManager
) {

    return declare(null, {
        // summary:
        //      Inline command mixin.
        // tags:
        //      internal xproduct

        requestContextChange: false,

        _viewModel: null,

        skippedAction: null,

        ignoredStatuses: null,

        ignoredContentTypes: ["episerver.core.contentfolder"],

        errorMessageHeading: "",

        successMessage: "",

        requiredAction: null,

        postscript: function () {
            this.inherited(arguments);

            this.messageService = this.messageService || dependency.resolve("epi.shell.MessageService");
            this._contentDataStore = dependency.resolve("epi.storeregistry").get("epi.cms.contentdata");

            this.own(topic.subscribe("/epi/cms/content/statuschange/", function (status, contentIdentity) {
                if (!this.model || !this.model.contentLink) {
                    return;
                }
                var updatedContentId = new ContentReference(contentIdentity.id).id;
                var currentModelId = new ContentReference(this.model.contentLink).id;
                if (updatedContentId === currentModelId) {
                    this._onModelChange();
                }
            }.bind(this)));
        },

        _getEnhancedStore: function () {
            if (this._enhancedStore) {
                return this._enhancedStore;
            }
            try {
                this._enhancedStore = dependency.resolve("epi.storeregistry").get("epi.cms.latestcontentversion");
                return this._enhancedStore;
            } catch (e) {
                this._enhancedStore = null;
            }
        },

        _execute: function () {
            // tags:
            //      protected

            var self = this;

            function showErrorMessage(error) {
                if (error) {
                    DialogService.alert({
                        heading: self.errorMessageHeading,
                        description: error
                    });
                    return false;
                }

                var query = {
                    contextId: self.model.contentData.contentLink,
                    contextTypeName: "epi.cms.contentdata",
                    typeName: "error"
                };
                var validationErrors = self.messageService.query(query).map(function (validationError) {
                    return validationError.message;
                });
                if (validationErrors.length > 0) {
                    DialogService.alertWithErrors({
                        heading: self.errorMessageHeading
                    }, validationErrors);
                    return false;
                }

                DialogService.alert("<strong>" + htmlEntities.encode(self.model.contentData.name) + ":</strong> " + self.errorMessageHeading);
                return false;
            }

            var messages = this.messageService.query({ contextId: this.model.contentData.contentLink });
            messages.forEach(function (message) {
                this.messageService.remove({ id: message.id });
            }, this);

            return this.inherited(arguments).then(function () {
                this.showMessage("<strong>" + htmlEntities.encode(this.model.contentData.name) + "</strong> " + self.successMessage);
                var contentReference = new ContentReference(this.model.contentData.contentLink);
                // Refresh the data in the store only if it's been published before
                if (contentReference.workId) {
                    this._contentDataStore.refresh(contentReference.toString()).then(function () {
                        topic.publish("/epi/cms/block/inline-updated");
                    });
                } else {
                    topic.publish("/epi/cms/block/inline-updated");
                }
                return true;
            }.bind(this)).otherwise(showErrorMessage)
                .always(function (result) {
                    this.set("isAvailable", false);
                    return result;
                }.bind(this));
        },

        destroy: function () {
            if (this._viewModel) {
                this._viewModel.destroy();
            }
            this.inherited(arguments);
        },


        _onContentStatusChange: function (result) {
            return result;
        },

        _isIgnoredContentType: function (typeIdentifier) {
            //  summary:
            //      Return true if the command doesn't support that content type

            return this.ignoredContentTypes.some(function (type) {
                return TypeDescriptorManager.isBaseTypeIdentifier(typeIdentifier, type);
            }, this);
        },

        _onModelChange: function () {
            // summary:
            //		Updates canExecute and isAvailable after the model has been updated.
            // tags:
            //      protected

            if (!this.model) {
                return;
            }

            if (this._isIgnoredContentType(this.model.typeIdentifier)) {
                this.set("isAvailable", false);
                return;
            }

            var _arguments = arguments;

            var store = this._getEnhancedStore();
            if (!store) {
                return;
            }

            return store.query({ id: this.model.contentLink, keepversion: true }).then(function (latestContent) {
                var contentData = latestContent;
                // we want to exit early if the page is already published or the user does not have proper access rights
                if (!contentData || this.ignoredStatuses.indexOf(contentData.status) !== -1 ||
                    contentData.isPartOfActiveApproval ||
                    !ContentActionSupport.hasAccessToAction(contentData, this.requiredAction) ||
                    (this.skippedAction && ContentActionSupport.hasAccessToAction(contentData, this.skippedAction))
                ) {
                    this._setCommandVisibility(false);
                    return;
                }

                this._setCommandVisibility(true);

                if (this._viewModel) {
                    this._viewModel.destroy();
                }
                this._viewModel = new ContentViewModel({
                    contentLink: contentData.contentLink,
                    contextTypeName: "epi.cms.contentdata"
                });
                this._viewModel.set("contentData", contentData);
                this.model = this._viewModel;

                this.inherited(_arguments);
            }.bind(this));
        },

        _setCommandVisibility: function (visible) {
            this.set("isAvailable", visible);
        },

        showMessage: function (message) {
            DialogService.alert(message);
        },

        tryToSaveAndExecute: function (form) {
            var deferred = true;
            if (form.get("isDirty")) {
                deferred = form.saveForm();
            }
            return when(deferred).then(function () {
                var preExecuteDeferred = true;
                // check if the command became available after the form was saved
                if (!this.get("canExecute")) {
                    // manually refresh its model to get most recent availability flags
                    preExecuteDeferred = this._onModelChange();
                }
                return when(preExecuteDeferred).then(function () {
                    if (this.get("isAvailable") && this.get("canExecute")) {
                        return this.execute();
                    }
                }.bind(this));
            }.bind(this));
        }
    });
});
